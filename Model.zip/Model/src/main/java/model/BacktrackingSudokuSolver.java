package model;

import java.io.Serial;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class BacktrackingSudokuSolver implements SudokuSolver, Serializable {
    private final Random random = new Random();

    @Serial
    private static final long serialVersionUID = 1L;

    @Override
    public void solve(SudokuBoard board) {
        solve(board, 0, 0);
    }

    public boolean solve(SudokuBoard board, int row, int col) {
        if (row >= 9) { //koniec planszy
            return true;
        }

        if (board.get(row, col) == 0) {
            List<Integer> numbers = new ArrayList<>();
            for (int i = 1; i <= 9; i++) {
                numbers.add(i);
            }
            Collections.shuffle(numbers, random);
            for (int number : numbers) {
                if (isSafe(board, row, col, number)) {
                    board.set(row, col, number);
                    if (solve(board, (row * 9 + col + 1) / 9, (row * 9 + col + 1) % 9)) {
                        return true;
                    }
                    board.set(row, col, 0);
                }
            }
            return false;
        }
        //dla czesciowo uzupelnionego sudoku
        return solve(board, (row * 9 + col + 1) / 9, (row * 9 + col + 1) % 9);
    }

    private boolean isSafe(SudokuBoard board, int row, int col, int number) {
        for (int i = 0; i < 9; i++) {
            if (board.get(row, i) == number || board.get(i, col) == number) {
                return false;
            }
        }
        int startRow = row / 3 * 3;
        int startCol = col / 3 * 3;
        for (int r = startRow; r < startRow + 3; r++) {
            for (int k = startCol; k < startCol + 3; k++) {
                if (board.get(r, k) == number) {
                    return false;
                }
            }
        }
        return true;
    }
}