package model;

import java.util.List;
import model.exceptions.DaoException;

public interface Dao<T> extends AutoCloseable {

    T read(String name) throws DaoException;

    void write(String name, T obj) throws DaoException;

    List<String> names() throws DaoException;

    @Override
    void close() throws DaoException;
}
