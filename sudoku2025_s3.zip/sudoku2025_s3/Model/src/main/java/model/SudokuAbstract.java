package model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;
import java.util.*;

public abstract class SudokuAbstract implements PropertyChangeListener, Serializable, Cloneable {
    private  List<SudokuField> pola;

    @Serial
    private static final long serialVersionUID = 1L;

      public SudokuAbstract(SudokuField[] fields) {
            if (fields.length != 9) {
                throw new IllegalArgumentException("Struktura Sudoku musi zawierać 9 pól.");
            }

            this.pola = Arrays.asList(fields);

        for (SudokuField field : this.pola) {
            field.addPropertyChangeListener(this);
        }
    }

    @Serial
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();

        for (SudokuField field : this.pola) {
            field.addPropertyChangeListener(this);
        }
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        this.verify();

    }

    public List<SudokuField> getFields() {
        return this.pola;
    }

    public boolean verify() {
        Set<Integer> rozne = new HashSet<>();
        for (SudokuField field : pola) {
            int pole = field.getFieldValue();
            if (pole == 0) {
                continue;
            }
            if (rozne.contains(pole)) {
                return false;
            }
            rozne.add(pole);
        }
        return true;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("pola", pola)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SudokuAbstract that = (SudokuAbstract) o;

        return new EqualsBuilder().append(pola, that.pola).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(pola).toHashCode();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        SudokuAbstract clone = (SudokuAbstract) super.clone();

        List<SudokuField> newFields = new ArrayList<>();
        for (SudokuField field : this.pola) {
            newFields.add(field.clone());
        }
        clone.pola = newFields;

        return clone;
    }
}