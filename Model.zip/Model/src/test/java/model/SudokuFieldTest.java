package model;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

@DisplayName("Testy klasy SudokuField")
public class SudokuFieldTest {

    private SudokuField sudokuField;

    @BeforeEach
    void rozpocznij() {
        this.sudokuField = new SudokuField();
    }

    @Test
    @DisplayName("Test 1: Czy get i set działają poprawnie")
    void testSetGet() {
        assertThrows(IllegalArgumentException.class, () -> sudokuField.setFieldValue(-1), "Nieodpowiednia wartosc pola, podaj liczbe od 0 do 9");
        assertThrows(IllegalArgumentException.class, () -> sudokuField.setFieldValue(10), "Nieodpowiednia wartosc pola, podaj liczbe od 0 do 9");
        assertEquals(0, sudokuField.getFieldValue());
        sudokuField.setFieldValue(3);
        assertEquals(3, sudokuField.getFieldValue());
    }

    @Test
    @DisplayName("Test 2: Equals i hashcode")
    void testEquals() {
        SudokuField sudokuField2 = new SudokuField();
        SudokuField sudokuField3 = sudokuField;

        assertEquals(sudokuField, sudokuField);
        assertEquals(sudokuField, sudokuField3);
        assertEquals(sudokuField.hashCode(), sudokuField3.hashCode());

        assertEquals(sudokuField, sudokuField2);
        assertEquals(sudokuField.hashCode(), sudokuField2.hashCode());

        assertEquals(sudokuField.equals(sudokuField2), sudokuField2.equals(sudokuField));

        assertNotEquals(null, sudokuField);
        assertFalse(sudokuField.equals(null), "Metoda equals powinna zwrócić false dla null");

        SudokuSolver solver = new BacktrackingSudokuSolver();
        assertNotEquals(sudokuField, solver);

    }

    @Test
    @DisplayName("Test 3: toString")
    void testToString() {
        assertEquals(sudokuField.toString().getClass(), "str".getClass());
    }

    @Test
    @DisplayName("Test 4: Głęboka kopia, equals i compareTo")
    void testClone() throws CloneNotSupportedException {
        SudokuField original = new SudokuField();
        original.setFieldValue(5);
        SudokuField clone = original.clone();

        assertEquals(0, original.compareTo(clone));

        assertThrows(NullPointerException.class, () -> original.compareTo(null));
    }




}
