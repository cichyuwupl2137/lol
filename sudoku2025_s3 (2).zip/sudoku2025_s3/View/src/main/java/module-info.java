module view {
    requires model;

    requires javafx.controls;
    requires javafx.fxml;
    requires org.slf4j;

    exports view;

    opens view to javafx.fxml;
}