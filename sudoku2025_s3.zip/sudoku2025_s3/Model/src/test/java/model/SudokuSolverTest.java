package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy klasy SudokuBoard")
class SudokuSolverTest {

    private SudokuBoard sudokuBoard;

    @BeforeEach
    void rozpocznij() {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        sudokuBoard = new SudokuBoard(solver);
    }


    @Test
    @DisplayName("Test 1: Czy solve generuje poprawną planszę")
    void testSolve() {

        int[][] board = new int[9][9];
        sudokuBoard.set(7,7,7); //sprawdzi czy solve() poprawnie poradzi sobie z częściowo wypełnioną planszą
        sudokuBoard.solveGame();

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                board[i][j] = sudokuBoard.get(i, j);
            }
        }

        assertDoesNotThrow(() -> {
            for (int i = 0; i < 9; i++) {
                Set<Integer> rowSet = new HashSet<>();
                for (int j = 0; j < 9; j++) {
                    assertTrue(board[i][j] >= 1 && board[i][j] <= 9, "Liczba poza zakresem 1-9 w wierszu " + i);
                    assertTrue(rowSet.add(board[i][j]), "Znaleziono duplikat w wierszu " + i);
                }
            }

            for (int i = 0; i < 9; i++) {
                Set<Integer> colSet = new HashSet<>();
                for (int j = 0; j < 9; j++) {
                    assertTrue(colSet.add(board[j][i]), "Znaleziono duplikat w kolumnie " + i);
                }
            }

            for (int blockRow = 0; blockRow < 9; blockRow += 3) {
                for (int blockCol = 0; blockCol < 9; blockCol += 3) {
                    Set<Integer> blockSet = new HashSet<>();
                    for (int r = blockRow; r < blockRow + 3; r++) {
                        for (int k = blockCol; k < blockCol + 3; k++) {
                            assertTrue(blockSet.add(board[r][k]), "Znaleziono duplikat w bloku [" + blockRow + "][" + blockCol + "]");
                        }
                    }
                }
            }

            assertEquals(7, sudokuBoard.get(7, 7));
        });
    }

    @Test
    @DisplayName("Test 2: Czy dwa kolejne wywołania generują różne plansze")
    void testCzyGenerujeRoznePlansze() {

        int[][] board1 = new  int[9][9];
        int[][] board2 = new  int[9][9];
        sudokuBoard.solveGame();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                board1[i][j] = sudokuBoard.get(i, j);
                sudokuBoard.set(i, j, 0);
            }
        }
        sudokuBoard.solveGame();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                board2[i][j] = sudokuBoard.get(i, j);
            }
        }

        assertFalse(Arrays.deepEquals(board1, board2), "Błąd: Dwa kolejne wywołania wygenerowały identyczne plansze.");
    }

}