package model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testy dla SudokuDao, FileSudokuDao i Factory")
public class SudokuDaoTest {
    @TempDir
    Path tempDirectory;

    private SudokuSolver solver;

    @BeforeEach
    void setUp() {
        solver = new BacktrackingSudokuSolver();
    }


    @Test
    @DisplayName("Test 1: Czy fabryka działa poprawnie?")
    void SudokuDaoFactoryTest() throws Exception {
        String sciezkaDoTestow = tempDirectory.toFile().getAbsolutePath();

        Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getFileDao(sciezkaDoTestow);

        assertNotNull(dao);
    }

    @Test
    @DisplayName("Test 2: Czy read i write działają poprawnie?")
    void SudokuDaoFactoryTest2() {
        String testName = "testName1";
        String sciezkaDoTestow = tempDirectory.toFile().getAbsolutePath();

        try (Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getFileDao(sciezkaDoTestow)){
            SudokuBoard plansza1 = new SudokuBoard(solver);
            plansza1.solveGame();
            plansza1.set(0,3,5);

            assertDoesNotThrow(() -> dao.write(testName, plansza1));

            SudokuBoard plansza2 = assertDoesNotThrow(() -> dao.read(testName));

            assertNotNull(plansza2);
            assertEquals(plansza1, plansza2);
            assertEquals(5, plansza2.get(0,3));

            assertTrue(dao.names().contains(testName));

            assertDoesNotThrow(() -> plansza2.set(0,6,7),
                    "Wczytana plansza ma problem z metodą setFieldValue - " +
                            " popraw metodę readObject!");

        } catch (Exception e) {
            fail("Test rzucił wyjątek: " + e.getMessage());
        }

    }
    @Test
    @DisplayName("Test 3: Czy metoda names() poprawnie filtruje katalogi")
    void SudokuDaoFactoryTest3() {
        String directoryPath = tempDirectory.toFile().getAbsolutePath();
        String fileName = "prawidlowy_plik";
        String directoryName = "niechciany_katalog";

        try (Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getFileDao(directoryPath)) {
            SudokuBoard board = new SudokuBoard(solver);
            dao.write(fileName, board);

            Files.createDirectory(tempDirectory.resolve(directoryName));

            List<String> names = dao.names();

            assertNotNull(names);
            assertEquals(1, names.size());
            assertTrue(names.contains(fileName));
            assertFalse(names.contains(directoryName));

        } catch (Exception e) {
            fail("Test rzucił wyjątek: " + e.getMessage());
        }
    }
    @Test
    @DisplayName("Test 4: Czy PropertyChangeListener działa po deserializacji")
    void SudokuDaoFactoryTest4() {
        String testName = "testListener";
        String sciezkaDoTestow = tempDirectory.toFile().getAbsolutePath();

        try (Dao<SudokuBoard> dao = SudokuBoardDaoFactory.getFileDao(sciezkaDoTestow)) {
            SudokuBoard plansza1 = new SudokuBoard(solver);
            plansza1.solveGame();
            dao.write(testName, plansza1);

            SudokuBoard plansza2 = dao.read(testName);

            assertTrue(plansza2.checkBoard(),
                    "Plansza powinna być poprawna po deserializacji");

            int pierwsza = plansza2.get(0, 0);
            plansza2.set(0, 1, pierwsza);

            assertFalse(plansza2.checkBoard(),
                    "Listener powinien wykryć błąd po deserializacji");

        } catch (Exception e) {
            fail("Test rzucił wyjątek: " + e.getMessage());
        }
    }


}
