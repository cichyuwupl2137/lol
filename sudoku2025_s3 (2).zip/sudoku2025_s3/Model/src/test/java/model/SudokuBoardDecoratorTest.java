package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SudokuBoardDecoratorTest {

    @Test
    void testDecoratorPreservesInitialState() throws CloneNotSupportedException {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        SudokuBoard board = new SudokuBoard(solver);
        board.solveGame();
        
        int initialValue = board.get(0, 0);
        
        SudokuBoardDecorator decorator = new SudokuBoardDecorator(board);
        
        assertEquals(initialValue, decorator.get(0, 0));
        assertEquals(initialValue, decorator.getInitialState().get(0, 0));
        
        int newValue = (initialValue + 1) % 9;
        if (newValue == 0) newValue = 1;
        decorator.set(0, 0, newValue);
        
        assertEquals(newValue, decorator.get(0, 0));
        
        assertEquals(initialValue, decorator.getInitialState().get(0, 0));
    }

    @Test
    void testClone() throws CloneNotSupportedException {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        SudokuBoard board = new SudokuBoard(solver);
        board.solveGame();
        
        SudokuBoardDecorator decorator = new SudokuBoardDecorator(board);
        decorator.set(0, 0, 5);
        
        SudokuBoardDecorator clonedDecorator = decorator.clone();
        
        clonedDecorator.set(0, 0, 9);
        
        assertNotEquals(clonedDecorator.get(0, 0), decorator.get(0, 0));
        assertEquals(5, decorator.get(0, 0));
        assertEquals(9, clonedDecorator.get(0, 0));
        
        assertNotSame(decorator.getInitialState(), clonedDecorator.getInitialState());
    }
    
    @Test
    void testDelegation() {
        SudokuSolver solver = new BacktrackingSudokuSolver();
        SudokuBoard board = new SudokuBoard(solver);
        SudokuBoardDecorator decorator = new SudokuBoardDecorator(board);
        
        board.solveGame();
        assertTrue(decorator.checkBoard());
        
        board.set(0, 0, board.get(0, 1));
        assertFalse(decorator.checkBoard());
    }
}
