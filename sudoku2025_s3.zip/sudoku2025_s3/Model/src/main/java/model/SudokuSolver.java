package model;

public interface SudokuSolver {
    void solve(SudokuBoard board);
}