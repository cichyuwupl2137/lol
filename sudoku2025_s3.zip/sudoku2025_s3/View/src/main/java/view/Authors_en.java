package view;

import java.util.ListResourceBundle;

public class Authors_en extends ListResourceBundle {
    @Override
    protected Object[][] getContents() {
        return new Object[][] {
            {"author.1", "Mateusz Buczko"},
            {"author.2", "Krzysztof Cichanski"}
        };
    }
}