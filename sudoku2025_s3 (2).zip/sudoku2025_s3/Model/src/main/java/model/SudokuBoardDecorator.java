package model;

import java.io.Serial;
import java.io.Serializable;

public class SudokuBoardDecorator extends SudokuBoard implements Serializable, Cloneable {
    
    @Serial
    private static final long serialVersionUID = 1L;

    private SudokuBoard currentState;
    private SudokuBoard initialState;

    public SudokuBoardDecorator(SudokuBoard board) {
        super(null); 
        this.currentState = board;
        try {
            this.initialState = board.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Failed to clone initial board", e);
        }
    }

    @Override
    public int get(int row, int col) {
        return currentState.get(row, col);
    }

    @Override
    public void set(int row, int col, int value) {
        currentState.set(row, col, value);
    }

    @Override
    public boolean checkBoard() {
        return currentState.checkBoard();
    }

    @Override
    public SudokuRow getRow(int y) {
        return currentState.getRow(y);
    }

    @Override
    public SudokuColumn getColumn(int x) {
        return currentState.getColumn(x);
    }

    @Override
    public SudokuBox getBox(int x, int y) {
        return currentState.getBox(x, y);
    }

    @Override
    public void solveGame() {
        currentState.solveGame();
    }

    public SudokuBoard getInitialState() {
        return initialState;
    }

    @Override
    public String toString() {
        return currentState.toString();
    }

    @Override
    public boolean equals(Object o) {
        return currentState.equals(o);
    }

    @Override
    public int hashCode() {
        return currentState.hashCode();
    }
    
    @Override
    public SudokuBoardDecorator clone() throws CloneNotSupportedException {
        SudokuBoardDecorator clone = (SudokuBoardDecorator) super.clone();
        clone.currentState = this.currentState.clone();
        clone.initialState = this.initialState.clone();
        return clone;
    }
}
