package view;

import javafx.util.converter.IntegerStringConverter;
import javafx.util.converter.NumberStringConverter;

public class CustomIntegerStringConverter extends NumberStringConverter {
    @Override
    public Number fromString(String string) {
        if (string == null || string.isBlank()) {
            return 0;
        }
        return super.fromString(string);
    }
    @Override
    public String toString(Number number) {
        if (number == null || number.intValue() == 0) {
            return "";
        }
        return super.toString(number);
    }
}
