package model;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serial;
import java.io.Serializable;

public class SudokuField implements Serializable, Cloneable, Comparable<SudokuField> {
    @Serial
    private static final long serialVersionUID = 1L;
    private int value;

    private transient PropertyChangeSupport support = new PropertyChangeSupport(this);

    public SudokuField() {
        this.value = 0;
    }

    public int getFieldValue() {
        return value;
    }

    public void setFieldValue(int value) {
        if (value >= 0 && value <= 9) {
            if (value == this.value) {
                return;
            }

            int oldValue = this.value;
            this.value = value;

            support.firePropertyChange("fieldValue", oldValue, this.value);

        } else {
            throw new IllegalArgumentException("Nieodpowiednia wartosc pola, podaj liczbe od 0 do 9");
        }
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        this.support.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        this.support.removePropertyChangeListener(listener);
    }

    @Serial
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {

        ois.defaultReadObject();

        support = new PropertyChangeSupport(this);

    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("value", value)
                .toString();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SudokuField that = (SudokuField) o;

        return new EqualsBuilder().append(value, that.value).isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37).append(value).toHashCode();
    }

    @Override
    public SudokuField clone() throws CloneNotSupportedException {
        SudokuField clone = (SudokuField) super.clone();
        clone.support = new PropertyChangeSupport(clone);
        return clone;
    }

    @Override
    public int compareTo(SudokuField o) {
        return Integer.compare(this.value, o.value);
    }
}