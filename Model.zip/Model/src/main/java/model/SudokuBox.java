package model;

public class SudokuBox extends SudokuAbstract {
    public SudokuBox(SudokuField[] fields) {
        super(fields);
    }


}
