package model.exceptions;

public class SudokuException extends Exception {
    public SudokuException(String message) {
        super(message);
    }
    public SudokuException(String message, Throwable cause) {
        super(message, cause);
    }
}
