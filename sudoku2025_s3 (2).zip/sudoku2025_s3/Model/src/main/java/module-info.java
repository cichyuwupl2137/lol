module model {
    requires org.apache.commons.lang3;
    requires java.desktop;
    requires org.slf4j;

    exports model;
    exports model.exceptions;

    opens model;
}