package model;


import model.exceptions.DaoException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.*;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Stream;



public class FileSudokuBoardDao implements Dao<SudokuBoard> {

    private static final Logger logger = LoggerFactory.getLogger(FileSudokuBoardDao.class);
    private static final ResourceBundle bundle = ResourceBundle.getBundle("ExceptionMessages");

    private final String directoryPath;

    public FileSudokuBoardDao(String directoryPath) throws DaoException {
        this.directoryPath = directoryPath;
        try {
            Files.createDirectories(Path.of(directoryPath));
        } catch (IOException e) {
            logger.error(bundle.getString("file.create.error"), e);
            throw new DaoException(bundle.getString("file.create.error") + directoryPath, e);
        }
    }

    @Override
    public SudokuBoard read(String name) throws DaoException {
        Path path = Paths.get(directoryPath, name);

        try (FileInputStream fileInputStream = new FileInputStream(path.toFile());
             ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {

            return (SudokuBoard) objectInputStream.readObject();

        } catch (ClassNotFoundException e) {
            logger.error(bundle.getString("class.not.found"), e);
            throw new DaoException(bundle.getString("class.not.found"), e);
        } catch (IOException e) {
            logger.error(bundle.getString("file.read.error"), e);
            throw new DaoException(bundle.getString("file.read.error") + name, e);
        }
    }

    @Override
    public void write(String name, SudokuBoard obj) throws DaoException {
        Path path = Paths.get(directoryPath, name);

        try (FileOutputStream fileOutputStream = new FileOutputStream(path.toFile());
             ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {

            objectOutputStream.writeObject(obj);

        } catch (IOException e) {
            logger.error(bundle.getString("file.write.error"), e);
            throw new DaoException(bundle.getString("file.write.error") + name, e);
        }
    }

    @Override
    public List<String> names() throws DaoException {
        try (Stream<Path> stream = Files.list(Path.of(directoryPath))) {
            return stream
                    .filter(file -> !Files.isDirectory(file))
                    .map(Path::getFileName)
                    .map(Path::toString)
                    .toList();
        } catch (IOException e) {
            logger.error(bundle.getString("file.read.error"), e);
            throw new DaoException(bundle.getString("file.read.error"), e);
        }
    }

    @Override
    public void close() throws DaoException {
    }
}