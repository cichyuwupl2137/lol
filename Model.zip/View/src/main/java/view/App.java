package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ResourceBundle;

public class App extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        ResourceBundle bundle = ResourceBundle.getBundle("SudokuBundle");
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("/view/menu.fxml"), bundle);
        Parent root = fxmlLoader.load();

        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.setTitle(bundle.getString("title.menu"));
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}