package view;

import model.*;
import model.exceptions.DaoException;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.adapter.JavaBeanIntegerProperty;
import javafx.beans.property.adapter.JavaBeanIntegerPropertyBuilder;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.layout.GridPane;
import javafx.util.converter.NumberStringConverter;

import java.util.function.UnaryOperator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SudokuController {

    private static final Logger logger = LoggerFactory.getLogger(SudokuController.class);

    @FXML
    private GridPane sudokuGrid;

    private SudokuBoard sudokuBoard;
    private final SudokuSolver solver = new BacktrackingSudokuSolver();

    private DifficultyLevel difficultyLevel = DifficultyLevel.EASY;

    @FXML
    private ComboBox<String> savedGamesComboBox;
    private Dao<SudokuBoard> dao;

    @FXML
    public void initialize() {
        try {
            dao = SudokuBoardDaoFactory.getFileDao("savedGames");
            refreshSavedGamesComboBox();
        } catch (DaoException e) {
            logger.error("Error initializing DAO", e);
            showError("Initialization Error", e.getMessage());
        }
    }

    public void setDifficultyLevel(DifficultyLevel difficultyLevel) {
        this.difficultyLevel = difficultyLevel;
    }

    @FXML
    private void onSaveGame() {
        if (sudokuBoard != null) {
            String name = "Sudoku-" + System.currentTimeMillis() + ".sud";
            try {
                dao.write(name, sudokuBoard);
                refreshSavedGamesComboBox();
            } catch (DaoException e) {
                logger.error("Error saving game", e);
                showError("Save Error", e.getMessage());
            }
        }
    }

    @FXML
    private void onLoadGame() {
        String select = savedGamesComboBox.getValue();
        if (select != null) {
            try {
                sudokuBoard = dao.read(select);
                fillGrid();
            } catch (DaoException e) {
                logger.error("Error loading game", e);
                showError("Load Error", e.getMessage());
            }
        }
    }

    private void refreshSavedGamesComboBox() {
        try {
            savedGamesComboBox.getItems().setAll(dao.names());
        } catch (DaoException e) {
            logger.error("Error refreshing saved games", e);
        }
    }

    @FXML
    private void onNewGame() {
        startNewGame();
    }

    public void startNewGame() {
        SudokuBoard baseBoard = new SudokuBoard(solver);
        baseBoard.solveGame();
        difficultyLevel.process(baseBoard);
        sudokuBoard = new SudokuBoardDecorator(baseBoard);
        fillGrid();
    }

    private void fillGrid() {
        sudokuGrid.getChildren().clear();

        for (int row = 0; row < 9; row++) {
            SudokuColumn sudokuColumn = sudokuBoard.getColumn(row);

            for (int col = 0; col < 9; col++) {
                TextField textField = new TextField();
                textField.setPrefWidth(40);
                textField.setPrefHeight(40);
                textField.setAlignment(Pos.CENTER);

                SudokuField field = sudokuColumn.getFields().get(col);

                JavaBeanIntegerProperty beanProperty = null;
                try {
                    JavaBeanIntegerPropertyBuilder integerPropertyBuilder = JavaBeanIntegerPropertyBuilder.create();
                    beanProperty = integerPropertyBuilder
                            .bean(field)
                            .name("fieldValue")
                            .setter("setFieldValue")
                            .getter("getFieldValue")
                            .build();
                } catch (NoSuchMethodException e) {
                    logger.error("Error creating property", e);
                }

                StringProperty stringProperty = new SimpleStringProperty();
                NumberStringConverter stringConverter = new CustomIntegerStringConverter();

                if (beanProperty != null) {
                    stringProperty.bindBidirectional(beanProperty, stringConverter);
                }

                textField.textProperty().bindBidirectional(stringProperty);

                if (field.getFieldValue() != 0) {
                    textField.setEditable(false);
                    textField.setStyle("-fx-background-color: #e0e0e0; -fx-font-weight: bold;");
                } else {
                    textField.setStyle("-fx-background-color: white;");
                    addInputValidation(textField);
                }

                sudokuGrid.add(textField, col, row);
            }
        }
    }

    private void addInputValidation(TextField field) {
        UnaryOperator<TextFormatter.Change> filter = change -> {
            String text = change.getControlNewText();
            if (text.matches("[1-9]?")) {
                return change;
            }
            return null;
        };
        field.setTextFormatter(new TextFormatter<>(new CustomIntegerStringConverter(), null, filter));
    }

    private void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}