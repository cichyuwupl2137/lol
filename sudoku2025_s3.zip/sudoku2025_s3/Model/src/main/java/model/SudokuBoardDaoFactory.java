package model;

import model.exceptions.DaoException;

public class SudokuBoardDaoFactory {

    private SudokuBoardDaoFactory() {
    }

    public static Dao<SudokuBoard> getFileDao(String directoryPath) throws DaoException {
        return new FileSudokuBoardDao(directoryPath);
    }
}
