package view;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import model.DifficultyLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Locale;
import java.util.ResourceBundle;

public class MenuController {

    private static final Logger logger = LoggerFactory.getLogger(MenuController.class);

    @FXML
    private ComboBox<DifficultyLevel> difficultyComboBox;

    @FXML
    private Label authorsLabel;

    @FXML
    public void initialize() {
        difficultyComboBox.getItems().addAll(DifficultyLevel.values());
        difficultyComboBox.setConverter(new javafx.util.StringConverter<>() {
            @Override
            public String toString(DifficultyLevel object) {
                if (object == null) {
                    return "";
                }
                try {
                    ResourceBundle bundle = ResourceBundle.getBundle("SudokuBundle");
                    return bundle.getString("difficulty." + object.name());
                } catch (Exception e) {
                    return object.name();
                }
            }

            @Override
            public DifficultyLevel fromString(String string) {
                return null;
            }
        });
        difficultyComboBox.getSelectionModel().selectFirst();
        loadAuthors();
    }

    private void loadAuthors() {
        try {
            ResourceBundle authors = ResourceBundle.getBundle("view.Authors");
            String a1 = authors.getString("author.1");
            String a2 = authors.getString("author.2");
            authorsLabel.setText(authorsLabel.getText() + " " + a1 + ", " + a2);
        } catch (Exception e) {
            logger.error("Failed to load authors", e);
        }
    }

    @FXML
    private void onStartGame() {
        DifficultyLevel selectedLevel = difficultyComboBox.getValue();

        if (selectedLevel != null) {
            startGame(selectedLevel);
        } else {
            ResourceBundle bundle = ResourceBundle.getBundle("SudokuBundle");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setContentText(bundle.getString("alert.difficulty"));
            alert.showAndWait();
        }
    }

    private void startGame(DifficultyLevel level) {
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("SudokuBundle");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/primary.fxml"), bundle);
            Parent root = loader.load();

            SudokuController sudokuController = loader.getController();
            sudokuController.setDifficultyLevel(level);
            sudokuController.startNewGame();

            Stage stage = (Stage) difficultyComboBox.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(bundle.getString("title.game") + " (" + level + ")");
            stage.show();

        } catch (IOException e) {
            logger.error("Failed to start game", e);
        }
    }

    @FXML
    private void onPlClick() {
        switchLanguage(new Locale("pl"));
    }

    @FXML
    private void onEnClick() {
        switchLanguage(new Locale("en"));
    }

    private void switchLanguage(Locale locale) {
        Locale.setDefault(locale);
        try {
            ResourceBundle bundle = ResourceBundle.getBundle("SudokuBundle", locale);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/menu.fxml"), bundle);
            Parent root = loader.load();
            Stage stage = (Stage) difficultyComboBox.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(bundle.getString("title.menu"));
            stage.show();
        } catch (IOException e) {
            logger.error("Failed to switch language", e);
        }
    }
}